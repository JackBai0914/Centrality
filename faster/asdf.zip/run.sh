# ./gen >inp.in
 # ./combine 1 >combine.out <inp.in
 ./fst >ans.txt <$1
