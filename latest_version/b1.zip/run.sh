./brute >ans.txt <$1
# ./combine 48 >ans.txt <$1
