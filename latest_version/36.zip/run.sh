# ./brute 48 >ans.txt <$1
./combine 36 >ans.txt <$1
