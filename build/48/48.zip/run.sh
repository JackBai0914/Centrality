chmod +x brandes
./brandes 48 input.in input.out >ans.txt <$1